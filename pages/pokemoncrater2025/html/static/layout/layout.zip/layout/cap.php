<?php

//start session which will be used to store generated numbers of validation in the form

session_start();

//generate random number between 10,000 and 99999

$number =mt_rand(10000, 99999);

//store generate random number to a session

$_SESSION['answer']=$number;

//create image 50 x 50 pixels

$imagecreate = imagecreate(50, 35);

// white background and blue text

$background = imagecolorallocate($imagecreate, 255, 255, 255);

$textcolor = imagecolorallocate($imagecreate, 0, 0, 255);

// write the string at the top left

imagestring($imagecreate, 5, 5, 10, $number, $textcolor);

// output the image

header("Content-type: image/png");

$image= imagepng($imagecreate);

?> 
