<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Anime Evolution</title>
<link rel="stylesheet" type="text/css" href="css/global.css" media="screen" />
</head>
<body>
<div class="container">
<div class="banner"></div>
<div class="header">
<ul class="nav">
<br/>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php">Forums</a></li>
<li><a href="/index.php">Anime List</a></li>
<li><a href="/index.php">Register</a></li>
<li><a href="/index.php">Sign In</a></li>
</ul>
<div style="text-align:right;margin:10px;"><form method="post"><tr><td><input type="text" size=10 name="search" class="textbox"></td> <td><INPUT TYPE="image" SRC="submit.png" HEIGHT="24" WIDTH="32" BORDER="0" ALT="Submit Form"></td></tr>
</form></div>
</div>
<div class="main">
<div class="content">

<div style="float:right;border-left:2px solid #C2C6CA;width:170px;height:600px;padding:10px;">
<iframe src="ads.php" allowtransparency="true" scrolling="no" width="160" height="600" frameborder="0"></iframe>
</div>
&nbsp;

<div style="min-height:600px;">

<h2>Register</h2>
<form method="POST">
<table border="0">
<tr><td>Username:</td><td><input type="text" name="username"></td></tr>
<r><td>&nbsp;</td></tr>
<tr><td>Password:</td><td><input type="text" name="password"></td></tr>
<r><td>&nbsp;</td></tr>
<tr><td>Confirm Password:</td><td><input type="text" name="confirm_passord"></td></tr>
<r><td>&nbsp;</td></tr>
<tr><td>Email:</td><td><input type="text" name="email"></td></tr>
<r><td>&nbsp;</td></tr>
<tr><td>Birthday:</td><td>
                
                  <select name="month" id="month" tabindex="5">
                    <option value="0" selected="selected">Month</option>
                    <option value="1">January</option>

                    <option value="2">February</option>
                    <option value="3">March</option>
                    <option value="4">April</option>
                    <option value="5">May</option>
                    <option value="6">June</option>
                    <option value="7">July</option>

                    <option value="8">August</option>
                    <option value="9">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>
                  </select>

                  <select name="day" id="day" tabindex="6">
                    <option value="0" selected="selected">Day</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>

                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>

                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>

                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21</option>
                    <option value="22">22</option>

                    <option value="23">23</option>
                    <option value="24">24</option>
                    <option value="25">25</option>
                    <option value="26">26</option>
                    <option value="27">27</option>
                    <option value="28">28</option>

                    <option value="29">29</option>
                    <option value="30">30</option>
                    <option value="31">31</option>
                  </select>
                  <select name="year" id="year" tabindex="7">
                    <option value="0" selected="selected">Year</option>
                    <option value="2009">2009</option>

                    <option value="2008">2008</option>
                    <option value="2007">2007</option>
                    <option value="2006">2006</option>
                    <option value="2005">2005</option>
                    <option value="2004">2004</option>
                    <option value="2003">2003</option>

                    <option value="2002">2002</option>
                    <option value="2001">2001</option>
                    <option value="2000">2000</option>
                    <option value="1999">1999</option>
                    <option value="1998">1998</option>
                    <option value="1997">1997</option>

                    <option value="1996">1996</option>
                    <option value="1995">1995</option>
                    <option value="1994">1994</option>
                    <option value="1993">1993</option>
                    <option value="1992">1992</option>
                    <option value="1991">1991</option>

                    <option value="1990">1990</option>
                    <option value="1989">1989</option>
                    <option value="1988">1988</option>
                    <option value="1987">1987</option>
                    <option value="1986">1986</option>
                    <option value="1985">1985</option>

                    <option value="1984">1984</option>
                    <option value="1983">1983</option>
                    <option value="1982">1982</option>
                    <option value="1981">1981</option>
                    <option value="1980">1980</option>
                    <option value="1979">1979</option>

                    <option value="1978">1978</option>
                    <option value="1977">1977</option>
                    <option value="1976">1976</option>
                    <option value="1975">1975</option>
                    <option value="1974">1974</option>
                    <option value="1973">1973</option>

                    <option value="1972">1972</option>
                    <option value="1971">1971</option>
                    <option value="1970">1970</option>
                    <option value="1969">1969</option>
                    <option value="1968">1968</option>
                    <option value="1967">1967</option>

                    <option value="1966">1966</option>
                    <option value="1965">1965</option>
                    <option value="1964">1964</option>
                    <option value="1963">1963</option>
                    <option value="1962">1962</option>
                    <option value="1961">1961</option>

                    <option value="1960">1960</option>
                    <option value="1959">1959</option>
                    <option value="1958">1958</option>
                    <option value="1957">1957</option>
                    <option value="1956">1956</option>
                    <option value="1955">1955</option>

                    <option value="1954">1954</option>
                    <option value="1953">1953</option>
                    <option value="1952">1952</option>
                    <option value="1951">1951</option>
                    <option value="1950">1950</option>
                    <option value="1949">1949</option>

                    <option value="1948">1948</option>
                    <option value="1947">1947</option>
                    <option value="1946">1946</option>
                    <option value="1945">1945</option>
                    <option value="1944">1944</option>
                    <option value="1943">1943</option>

                    <option value="1942">1942</option>
                    <option value="1941">1941</option>
                    <option value="1940">1940</option>
                    <option value="1939">1939</option>
                    <option value="1938">1938</option>
                    <option value="1937">1937</option>

                    <option value="1936">1936</option>
                    <option value="1935">1935</option>
                    <option value="1934">1934</option>
                    <option value="1933">1933</option>
                    <option value="1932">1932</option>
                    <option value="1931">1931</option>

                    <option value="1930">1930</option>
                    <option value="1929">1929</option>
                    <option value="1928">1928</option>
                    <option value="1927">1927</option>
                    <option value="1926">1926</option>
                    <option value="1925">1925</option>

                    <option value="1924">1924</option>
                    <option value="1923">1923</option>
                    <option value="1922">1922</option>
                    <option value="1921">1921</option>
                    <option value="1920">1920</option>
                    <option value="1919">1919</option>

                    <option value="1918">1918</option>
                    <option value="1917">1917</option>
                    <option value="1916">1916</option>
                    <option value="1915">1915</option>
                    <option value="1914">1914</option>
                    <option value="1913">1913</option>

                    <option value="1912">1912</option>
                    <option value="1911">1911</option>
                    <option value="1910">1910</option>
                    <option value="1909">1909</option>
                    <option value="1908">1908</option>
                    <option value="1907">1907</option>

                    <option value="1906">1906</option>
                    <option value="1905">1905</option>
                    <option value="1904">1904</option>
                    <option value="1903">1903</option>
                    <option value="1902">1902</option>
                    <option value="1901">1901</option>

                    <option value="1900">1900</option>
                  </select>
</td></tr><r><td>&nbsp;</td></tr>
<tr><td>Gender:</td><td>                 <select name="gender" id="gender" tabindex="8">
                    <option value=" " selected="selected"> </option>
                    <option value="f">Female</option>
                    <option value="m">Male</option>
                  </select></td></tr><r><td>&nbsp;</td></tr>

<tr><td>Country:</td><td><select name="country" id="country" tabindex="9">
                    <option value="US" selected="selected">United States</option>

                    <option value="CA">Canada</option>
                    <option value="AD">Andorra</option>
                    <option value="AF">Afghanistan</option>
                    <option value="AG">Antigua and Barbuda</option>
                    <option value="AI">Anguilla</option>
                    <option value="AL">Albania</option>

                    <option value="AM">Armenia</option>
                    <option value="AN">Netherlands Antilles</option>
                    <option value="AO">Angola</option>
                    <option value="AQ">Antarctica</option>
                    <option value="AR">Argentina</option>
                    <option value="AS">American Samoa</option>

                    <option value="AT">Austria</option>
                    <option value="AU">Australia</option>
                    <option value="AW">Aruba</option>
                    <option value="AX">Aland Islands</option>
                    <option value="AZ">Azerbaijan</option>
                    <option value="BA">Bosnia and Herzegovina</option>

                    <option value="BB">Barbados</option>
                    <option value="BD">Bangladesh</option>
                    <option value="BE">Belgium</option>
                    <option value="BF">Burkina Faso</option>
                    <option value="BG">Bulgaria</option>
                    <option value="BH">Bahrain</option>

                    <option value="BI">Burundi</option>
                    <option value="BJ">Benin</option>
                    <option value="BM">Bermuda</option>
                    <option value="BN">Brunei Darussalam</option>
                    <option value="BO">Bolivia</option>
                    <option value="BR">Brazil</option>

                    <option value="BS">Bahamas</option>
                    <option value="BT">Bhutan</option>
                    <option value="BV">Bouvet Island</option>
                    <option value="BW">Botswana</option>
                    <option value="BY">Belarus</option>
                    <option value="BZ">Belize</option>

                    <option value="CC">Cocos (Keeling) Islands</option>
                    <option value="CD">Democratic Republic of the Congo</option>
                    <option value="CF">Central African Republic</option>
                    <option value="CG">Congo</option>
                    <option value="CH">Switzerland</option>
                    <option value="CI">Cote D'Ivoire (Ivory Coast)</option>

                    <option value="CK">Cook Islands</option>
                    <option value="CL">Chile</option>
                    <option value="CM">Cameroon</option>
                    <option value="CN">China</option>
                    <option value="CO">Colombia</option>
                    <option value="CR">Costa Rica</option>

                    <option value="CS">Serbia and Montenegro</option>
                    <option value="CU">Cuba</option>
                    <option value="CV">Cape Verde</option>
                    <option value="CX">Christmas Island</option>
                    <option value="CY">Cyprus</option>
                    <option value="CZ">Czech Republic</option>

                    <option value="DE">Germany</option>
                    <option value="DJ">Djibouti</option>
                    <option value="DK">Denmark</option>
                    <option value="DM">Dominica</option>
                    <option value="DO">Dominican Republic</option>
                    <option value="DZ">Algeria</option>

                    <option value="EC">Ecuador</option>
                    <option value="EE">Estonia</option>
                    <option value="EG">Egypt</option>
                    <option value="EH">Western Sahara</option>
                    <option value="ER">Eritrea</option>
                    <option value="ES">Spain</option>

                    <option value="ET">Ethiopia</option>
                    <option value="FI">Finland</option>
                    <option value="FJ">Fiji</option>
                    <option value="FK">Falkland Islands (Malvinas)</option>
                    <option value="FM">Federated States of Micronesia</option>
                    <option value="FO">Faroe Islands</option>

                    <option value="FR">France</option>
                    <option value="FX">France, Metropolitan</option>
                    <option value="GA">Gabon</option>
                    <option value="GB">Great Britain (UK)</option>
                    <option value="GD">Grenada</option>
                    <option value="GE">Georgia</option>

                    <option value="GF">French Guiana</option>
                    <option value="GH">Ghana</option>
                    <option value="GI">Gibraltar</option>
                    <option value="GL">Greenland</option>
                    <option value="GM">Gambia</option>
                    <option value="GN">Guinea</option>

                    <option value="GP">Guadeloupe</option>
                    <option value="GQ">Equatorial Guinea</option>
                    <option value="GR">Greece</option>
                    <option value="GS">S. Georgia and S. Sandwich Islands</option>
                    <option value="GT">Guatemala</option>
                    <option value="GU">Guam</option>

                    <option value="GW">Guinea-Bissau</option>
                    <option value="GY">Guyana</option>
                    <option value="HK">Hong Kong</option>
                    <option value="HM">Heard Island and McDonald Islands</option>
                    <option value="HN">Honduras</option>
                    <option value="HR">Croatia (Hrvatska)</option>

                    <option value="HT">Haiti</option>
                    <option value="HU">Hungary</option>
                    <option value="ID">Indonesia</option>
                    <option value="IE">Ireland</option>
                    <option value="IL">Israel</option>
                    <option value="IN">India</option>

                    <option value="IO">British Indian Ocean Territory</option>
                    <option value="IQ">Iraq</option>
                    <option value="IR">Iran</option>
                    <option value="IS">Iceland</option>
                    <option value="IT">Italy</option>
                    <option value="JM">Jamaica</option>

                    <option value="JO">Jordan</option>
                    <option value="JP">Japan</option>
                    <option value="KE">Kenya</option>
                    <option value="KG">Kyrgyzstan</option>
                    <option value="KH">Cambodia</option>
                    <option value="KI">Kiribati</option>

                    <option value="KM">Comoros</option>
                    <option value="KN">Saint Kitts and Nevis</option>
                    <option value="KP">Korea (North)</option>
                    <option value="KR">Korea (South)</option>
                    <option value="KW">Kuwait</option>
                    <option value="KY">Cayman Islands</option>

                    <option value="KZ">Kazakhstan</option>
                    <option value="LA">Laos</option>
                    <option value="LB">Lebanon</option>
                    <option value="LC">Saint Lucia</option>
                    <option value="LI">Liechtenstein</option>
                    <option value="LK">Sri Lanka</option>

                    <option value="LR">Liberia</option>
                    <option value="LS">Lesotho</option>
                    <option value="LT">Lithuania</option>
                    <option value="LU">Luxembourg</option>
                    <option value="LV">Latvia</option>
                    <option value="LY">Libya</option>

                    <option value="MA">Morocco</option>
                    <option value="MC">Monaco</option>
                    <option value="MD">Moldova</option>
                    <option value="MG">Madagascar</option>
                    <option value="MH">Marshall Islands</option>
                    <option value="MK">Macedonia</option>

                    <option value="ML">Mali</option>
                    <option value="MM">Myanmar</option>
                    <option value="MN">Mongolia</option>
                    <option value="MO">Macao</option>
                    <option value="MP">Northern Mariana Islands</option>
                    <option value="MQ">Martinique</option>

                    <option value="MR">Mauritania</option>
                    <option value="MS">Montserrat</option>
                    <option value="MT">Malta</option>
                    <option value="MU">Mauritius</option>
                    <option value="MV">Maldives</option>
                    <option value="MW">Malawi</option>

                    <option value="MX">Mexico</option>
                    <option value="MY">Malaysia</option>
                    <option value="MZ">Mozambique</option>
                    <option value="NA">Namibia</option>
                    <option value="NC">New Caledonia</option>
                    <option value="NE">Niger</option>

                    <option value="NF">Norfolk Island</option>
                    <option value="NG">Nigeria</option>
                    <option value="NI">Nicaragua</option>
                    <option value="NL">Netherlands</option>
                    <option value="NO">Norway</option>
                    <option value="NP">Nepal</option>

                    <option value="NR">Nauru</option>
                    <option value="NU">Niue</option>
                    <option value="NZ">New Zealand (Aotearoa)</option>
                    <option value="OM">Oman</option>
                    <option value="PA">Panama</option>
                    <option value="PE">Peru</option>

                    <option value="PF">French Polynesia</option>
                    <option value="PG">Papua New Guinea</option>
                    <option value="PH">Philippines</option>
                    <option value="PK">Pakistan</option>
                    <option value="PL">Poland</option>
                    <option value="PM">Saint Pierre and Miquelon</option>

                    <option value="PN">Pitcairn</option>
                    <option value="PR">Puerto Rico</option>
                    <option value="PS">Palestinian Territory</option>
                    <option value="PT">Portugal</option>
                    <option value="PW">Palau</option>
                    <option value="PY">Paraguay</option>

                    <option value="QA">Qatar</option>
                    <option value="RE">Reunion</option>
                    <option value="RO">Romania</option>
                    <option value="RU">Russia</option>
                    <option value="RW">Rwanda</option>
                    <option value="SA">Saudi Arabia</option>

                    <option value="SB">Solomon Islands</option>
                    <option value="SC">Seychelles</option>
                    <option value="SD">Sudan</option>
                    <option value="SE">Sweden</option>
                    <option value="SG">Singapore</option>
                    <option value="SH">Saint Helena</option>

                    <option value="SI">Slovenia</option>
                    <option value="SJ">Svalbard and Jan Mayen</option>
                    <option value="SK">Slovakia</option>
                    <option value="SL">Sierra Leone</option>
                    <option value="SM">San Marino</option>
                    <option value="SN">Senegal</option>

                    <option value="SO">Somalia</option>
                    <option value="SR">Suriname</option>
                    <option value="ST">Sao Tome and Principe</option>
                    <option value="SV">El Salvador</option>
                    <option value="SY">Syria</option>
                    <option value="SZ">Swaziland</option>

                    <option value="TC">Turks and Caicos Islands</option>
                    <option value="TD">Chad</option>
                    <option value="TF">French Southern Territories</option>
                    <option value="TG">Togo</option>
                    <option value="TH">Thailand</option>
                    <option value="TJ">Tajikistan</option>

                    <option value="TK">Tokelau</option>
                    <option value="TL">Timor-Leste</option>
                    <option value="TM">Turkmenistan</option>
                    <option value="TN">Tunisia</option>
                    <option value="TO">Tonga</option>
                    <option value="TP">East Timor</option>

                    <option value="TR">Turkey</option>
                    <option value="TT">Trinidad and Tobago</option>
                    <option value="TV">Tuvalu</option>
                    <option value="TW">Taiwan</option>
                    <option value="TZ">Tanzania</option>
                    <option value="UA">Ukraine</option>

                    <option value="UG">Uganda</option>
                    <option value="AE">United Arab Emirates</option>
                    <option value="UK">United Kingdom</option>
                    <option value="UM">United States Minor Outlying Islands</option>
                    <option value="UY">Uruguay</option>
                    <option value="UZ">Uzbekistan</option>

                    <option value="VA">Vatican City State (Holy See)</option>
                    <option value="VC">Saint Vincent and the Grenadines</option>
                    <option value="VE">Venezuela</option>
                    <option value="VG">Virgin Islands (British)</option>
                    <option value="VI">Virgin Islands (U.S.)</option>
                    <option value="VN">Vietnam</option>

                    <option value="VU">Vanuatu</option>
                    <option value="WF">Wallis and Futuna</option>
                    <option value="WS">Samoa</option>
                    <option value="YE">Yemen</option>
                    <option value="YT">Mayotte</option>
                    <option value="ZA">South Africa</option>

                    <option value="ZM">Zambia</option>
                    <option value="ZW">Zimbabwe</option>
                  </select>
</td></tr>
<tr><td><img src="cap.php" />

</td></tr><tr><td>

Type the security code above:

 </td><td>

<input type="text" name="captcha" size="10"> </td></tr>
</table></form>

</div> 
&nbsp;
</div></div>



<div class="bottom"></div>
<div class="copy"> 	
	<a href="http://anime-evolution.net/about/legal.php">Legal Info</a> | <a href="http://anime-evolution.net/about/faq.php">FAQ</a> | <a href="http://anime-evolution.net/about/about.php">About Us</a> | <a href="http://anime-evolution.net/about/contact.php">Contact Us</a> | <a href="http://anime-evolution.net/donate.php">Donate</a>

		
	
		<span>All Content is Copyright of Anime Evolution 2009. 
</span>

</div>
</div>

</body>
</html>

