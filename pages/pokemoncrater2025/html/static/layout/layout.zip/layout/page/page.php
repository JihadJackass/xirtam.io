<?
echo $_REQUEST['id'];
?>
